<?php
	if(mail('aleksey@zinocj.ru', 'test', 'testin')) {
		echo 'Письмо отправлено';
	}
?>