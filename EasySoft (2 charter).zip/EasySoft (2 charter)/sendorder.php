<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
	
	//test
	use PHPMailer\PHPMailer\SMTP;

    require 'phpmailer/src/Exception.php';
    require 'phpmailer/src/PHPMailer.php';
	//test
	require 'phpmailer/src/SMTP.php';
	

    $mail = new PHPMailer(true);
	
	//тест
	//$mail->SMTPDebug = SMTP::DEBUG_SERVER;
	$mail->isSMTP();
	$mail->Host = 'mail.nic.ru';
	$mail->SMTPAuth = true;
	$mail->Username = 'order@zinoch.ru'; // логин
	$mail->Password = '77777777Zz'; // пароль
	$mail->SMTPOptions = array(
        'ssl' => array(
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true
        )
    );
	$mail->SMTPSecure = 'ssl';
	//$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  
	$mail->Port = 465;
	
	
	//----
	
    $mail->CharSet = 'UTF-8';
    $mail->setLanguage('ru', 'phpmailer/language/');
    $mail->isHTML(true);


    //От кого письмо
    $mail->setFrom('order@zinoch.ru', 'Заказ');
    //Кому отправить
	 $mail->addAddress('amk.honey@yandex.ru');
	 $mail->addAddress('aleksey@zinoch.ru');
    //Тема письма
    $mail->Subject = 'Заказ Мёда';

    //Тело письма

    $body = '<h1> Заказ </h1>';

    if(trim(!empty($_POST['name']))){
        $body.='<p><strong>Имя:</strong> '.$_POST['name'].'</p>';
    }
    if(trim(!empty($_POST['email']))){
        $body.='<p><strong>E-mail:</strong> '.$_POST['email'].'</p>';
    }
    if(trim(!empty($_POST['telephone']))){
        $body.='<p><strong>Телефон:</strong> '.$_POST['telephone'].'</p>';
    }
    if(trim(!empty($_POST['comment']))){
        $body.='<p><strong>Коментарий:</strong> '.$_POST['comment'].'</p>';
    }




    $mail->Body = $body;

    //Отправляем
    if (!$mail->send()) {
        $message = 'Ошибка';
    } else {
        $message = ' Данные отправлены!';
    }

    $response = ['message' => $message];

    header('Content-type: application/jcon');
    echo json_encode($response);
	//echo $mail->Subject;
?>
